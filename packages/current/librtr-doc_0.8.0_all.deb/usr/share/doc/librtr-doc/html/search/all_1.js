var searchData=
[
  ['bgp_5fpfxv_5fstate_5finvalid_0',['BGP_PFXV_STATE_INVALID',['../group__mod__pfx__h.html#gga9f87b27f024a9db70884c3981e030aa0aae9350d7596c31ff7a04d7a4c34a0459',1,'pfx.h']]],
  ['bgp_5fpfxv_5fstate_5fnot_5ffound_1',['BGP_PFXV_STATE_NOT_FOUND',['../group__mod__pfx__h.html#gga9f87b27f024a9db70884c3981e030aa0af4c75701949d919bae43e92f5e656342',1,'pfx.h']]],
  ['bgp_5fpfxv_5fstate_5fvalid_2',['BGP_PFXV_STATE_VALID',['../group__mod__pfx__h.html#gga9f87b27f024a9db70884c3981e030aa0a822b53f311ed40e3f91c44f6ac2c6c92',1,'pfx.h']]]
];
