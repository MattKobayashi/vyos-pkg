var searchData=
[
  ['tr_5fssh_5finit_0',['tr_ssh_init',['../group__mod__ssh__transport__h.html#gac5d5516e62228cc180c6aaac467bfe6c',1,'ssh_transport.h']]],
  ['tr_5ftcp_5finit_1',['tr_tcp_init',['../group__mod__tcp__transport__h.html#ga6335c26aa03290ba3524829574e472e0',1,'tcp_transport.h']]]
];
