var searchData=
[
  ['tr_5fclose_5ffp_0',['tr_close_fp',['../group__mod__transport__h.html#gad2efbef8b157cd9484c688d6ef67d6b6',1,'transport.h']]],
  ['tr_5ffree_5ffp_1',['tr_free_fp',['../group__mod__transport__h.html#ga333a8d2d3a3dea54a36034c026d0a054',1,'transport.h']]],
  ['tr_5fident_5ffp_2',['tr_ident_fp',['../group__mod__transport__h.html#ga02f9d37bf7e41a8990b74af6653cae6c',1,'transport.h']]],
  ['tr_5fopen_5ffp_3',['tr_open_fp',['../group__mod__transport__h.html#ga615d56abf17d32924155fcf0ccc2664c',1,'transport.h']]],
  ['tr_5frecv_5ffp_4',['tr_recv_fp',['../group__mod__transport__h.html#ga257bfa5c831410f1034edaa9b79f303c',1,'transport.h']]],
  ['tr_5fsend_5ffp_5',['tr_send_fp',['../group__mod__transport__h.html#gadc6f1fbce8f7557edd50070069afc0c6',1,'transport.h']]]
];
