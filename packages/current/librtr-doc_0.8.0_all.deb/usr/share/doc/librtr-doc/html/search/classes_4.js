var searchData=
[
  ['tr_5fsocket_0',['tr_socket',['../structtr__socket.html',1,'']]],
  ['tr_5fssh_5fconfig_1',['tr_ssh_config',['../structtr__ssh__config.html',1,'']]],
  ['tr_5ftcp_5fconfig_2',['tr_tcp_config',['../structtr__tcp__config.html',1,'']]]
];
