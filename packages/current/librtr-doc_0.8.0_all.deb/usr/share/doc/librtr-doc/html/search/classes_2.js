var searchData=
[
  ['rtr_5fmgr_5fgroup_0',['rtr_mgr_group',['../structrtr__mgr__group.html',1,'']]],
  ['rtr_5fsocket_1',['rtr_socket',['../structrtr__socket.html',1,'']]]
];
